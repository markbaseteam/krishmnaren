## Krishnan Minnalur Shankarnarayanan

- Highly experienced Senior Principal Product Manager with 20+ years in product management and leadership
- Proven track record of creating, launching and managing successful products across a broad range of markets globally
- Skilled at developing partnerships within organization to take innovative ideas from concept to market quickly
- Highly analytical leader with excellent problem solving abilities and an exceptional ability to communicate effectively both internally and externally
- Experienced in developing marketing strategy, product plans, messaging, release milestones, customer segmentation strategies and analyzing cross functional business objectives while staying true to company’s core values
- Adept at taking ownership of multiple projects simultaneously while leading others into success through metrics driven decision making as well as building teams that achieve results under tight timelines

## Skills
### Platform
- Salesforce
- Apttus
- Zuora
- Oracle 
- IBM

### Domain
- CRM
- Configure, Price, Quote
- Contract Lifecycle Management
- Subscription Billing
- Payments
- Revenue Recognition
- Partner commerce
- Customer Success

### Product Management
- Competitive Analysis
- User Experience
- Solution Design
- Customer Relationship
- Stakeholder Management
- Data Analysis
- Leadership
- Roadmap Definition
- SAFe Agile
- Cross Functional Collaboration
